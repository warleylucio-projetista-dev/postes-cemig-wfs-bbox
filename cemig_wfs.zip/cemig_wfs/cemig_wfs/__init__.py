# -----------------------------------------------------------------------------
# Projeto: CEMIG WFS
# Autor: Warley Lúcio (Projetista-DEV)
# Licença: GNU General Public License v3.0 (GPL-3.0)
# Repositório: https://github.com/warleylucio-projetista-dev/cemig_wfs
# -----------------------------------------------------------------------------
def classFactory(iface):
    from .cemig_wfs_plugin import CemigWFSPlugin
    return CemigWFSPlugin(iface)

