# -----------------------------------------------------------------------------
# Projeto: CEMIG WFS
# Autor: Warley Lúcio - 2026
# Licença: GNU General Public License v3.0 (GPL-3.0)
# Repositório: https://github.com/warleylucio-projetista-dev/cemig_wfs
# -----------------------------------------------------------------------------
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsProject, QgsVectorLayer
from qgis.utils import iface
import urllib.request
from datetime import datetime
import os

BASE_WFS = "https://ci.cemig.com.br/ciweb/api/geocoder/ATLANTIS/ows"
TYPENAME = "ATLANTIS:POSTE_SELECT"
CRS = "EPSG:3857"


class CemigWFSPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        self.action = QAction(
            "CEMIG – Coletar Postes (WFS)",
            self.iface.mainWindow()
        )

        self.action.setToolTip(
            "Coleta postes da CEMIG via WFS usando o \n enquadramento atual do mapa.\n\n"
            "⚠️ IMPORTANTE:\n"
            "• Utilize zoom aproximado entre 500m e 1km\n"
            "• Áreas muito pequenas podem não retornar dados"
        )

        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&CEMIG WFS", self.action)

    def unload(self):
        self.iface.removePluginMenu("&CEMIG WFS", self.action)

    def run(self):
        canvas = self.iface.mapCanvas()
        extent = canvas.extent()

        xmin = extent.xMinimum()
        ymin = extent.yMinimum()
        xmax = extent.xMaximum()
        ymax = extent.yMaximum()

        bbox = f"{xmin},{ymin},{xmax},{ymax},{CRS}"

        url = (
            f"{BASE_WFS}?service=WFS&version=1.0.0&request=GetFeature"
            f"&typename={TYPENAME}"
            f"&outputFormat=application/json"
            f"&srsname={CRS}"
            f"&bbox={bbox}"
        )

        # ================== NOME DO ARQUIVO COM CONTADOR ==================
        data_hoje = datetime.now().strftime("%d-%m-%Y")
        pasta_saida = os.path.expanduser("~")

        base_name = f"Postes CEMIG - {data_hoje}"
        output = os.path.join(pasta_saida, f"{base_name}.geojson")

        contador = 1
        while os.path.exists(output):
            output = os.path.join(
                pasta_saida,
                f"{base_name}_{contador:02d}.geojson"
            )
            contador += 1
        # =================================================================

        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0"}
            )

            with urllib.request.urlopen(req, timeout=60) as response:
                data = response.read().decode("utf-8")

            if '"features":[]' in data or not data.strip():
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    "⚠️ Aviso",
                    "Ajuste o seu (EPSG: 3857)?\n"
                    "A área de coleta é: Minas Gerais.\n"
                    "Nenhum poste retornado para esta área.\n\n"
                    "🔎 Sugestão:\n"
                    "• Reduza o zoom (amplie a área visível)\n"
                    "• Evite enquadramentos muito pequenos.\n"
                    "• Evite enquadramentos muito grandes.\n"
                    "• Ideal: 500m x 500m / Máximo: 1Km x 1Km."
                )
                return

            with open(output, "w", encoding="utf-8") as f:
                f.write(data)

            layer = QgsVectorLayer(output, "Postes CEMIG - {data_hoje}", "ogr")

            if not layer.isValid():
                raise Exception("Camada inválida gerada pelo WFS.")

            QgsProject.instance().addMapLayer(layer)

            QMessageBox.information(
                self.iface.mainWindow(),
                "Sucesso",
                f"Postes carregados com sucesso!\n\n"
                f"Arquivo gerado:\n{output}"
            )

        except Exception as e:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Erro",
                str(e)
            )
